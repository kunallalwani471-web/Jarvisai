// Compatibility route: the project now uses Groq.
export { default } from './groq.js';
